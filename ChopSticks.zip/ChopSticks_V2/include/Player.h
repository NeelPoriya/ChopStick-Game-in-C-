#ifndef PLAYER_H
#define PLAYER_H
#include <bits/stdc++.h>
using namespace std;

class Player
{
    private:
        string name;
        int left_hand;
        int right_hand;
        int id;
    public:
        Player();
        string getName();
        void setName(string);
        int getLeftHand();
        void setLeftHand(int);
        int getRightHand();
        void setRightHand(int);
        void changeLeftHand(int);
        void changeRightHand(int);
        bool one_empty();
        int getID();
        void setID(int);
        bool has_lost();
};

#endif // PLAYER_H
