#ifndef QUEUE_H
#define QUEUE_H
#include <bits/stdc++.h>
#include "Player.h"
using namespace std;

struct Node{
    Player* player;
    Node* link;
};

class Queue
{
    private:
        Node* front;
        Node* rear;
        int SIZE;
    public:
        Queue();
        void enqueue(Player* p);
        void display();
        Player* Front();
        void dequeue();
        int size();
        bool empty();
        Player* Rear();
};

#endif // QUEUE_H
