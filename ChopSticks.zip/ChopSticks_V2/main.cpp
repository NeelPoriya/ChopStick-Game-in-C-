#include <bits/stdc++.h>
#include "Player.h"
#include "Queue.h"
#include "windows.h"

using namespace std;

void display(Player[], int);
void gotoxy(int x, int y);

int main()
{
    system("color E4");
    stack<Player> leaderBoard;

    int no_of_players, playerID, give, hand, choice;
    Player *other;
    do
    {
        cout << "How many players do you want : ";
        cin >> no_of_players;
    } while (no_of_players <= 1);
    getchar();
    Player players[no_of_players];

    for (int i = 0; i < no_of_players; i++)
    {
        string name;
        cout << "Enter the name of player " << i + 1 << " : ";
        getline(cin, name);
        players[i].setName(name);
        players[i].setID(i + 1);
    }
    Queue activePlayers;

    for (int i = 0; i < no_of_players; i++)
    {
        activePlayers.enqueue(&players[i]);
    }

    while (activePlayers.size() != 1)
    {
        system("CLS");
        display(players, no_of_players);

        if (activePlayers.Front()->has_lost())
        {
            leaderBoard.push(players[activePlayers.Front()->getID()-1]);
            activePlayers.dequeue();
            continue;
        }
        Player* currentPlayer = activePlayers.Front();
        do{
            Player* temp = activePlayers.Front();
            activePlayers.dequeue();
            if(temp->has_lost()){
                leaderBoard.push(players[temp->getID()-1]);
                continue;
            }
            activePlayers.enqueue(temp);
        }while(activePlayers.Front() != currentPlayer);

        if (activePlayers.size() > 2)
        {
            do
            {
                cout << activePlayers.Front()->getName() << "'s turn, What do you want to do :\n1. Attack\n2. Split\nEnter your choice : ";
                cin >> choice;
            } while (choice != 1 && choice != 2);

            if (choice == 1)
            {
                //give hand
                while (true)
                {
                    cout << activePlayers.Front()->getName() << ", Who would you like to give hand : ";
                    cin >> playerID;
                    if (playerID == activePlayers.Front()->getID())
                    {
                        cout << "You cannot give hand to yourself." << endl;
                    }
                    else if (players[playerID - 1].has_lost())
                    {
                        cout << "The player is already out." << endl;
                    }
                    else
                        break;
                }
                other = &players[playerID - 1];
                if (activePlayers.Front()->one_empty())
                {
                    //gives the hand automatically without asking for left or right.
                    if (activePlayers.Front()->getLeftHand() != 0)
                    {
                        //take the left hand's value as sender.
                        give = activePlayers.Front()->getLeftHand();
                    }
                    else
                    {
                        //give the value at right's hands place
                        give = activePlayers.Front()->getRightHand();
                    }
                }
                else
                {
                    //ask for left/right hand to give to.
                    do
                    {
                        cout << "Which of your hand will you like to give : (1. Left, 2. Right) ";
                        cin >> hand;
                    } while (hand != 1 && hand != 2);
                    if (hand == 1)
                        give = activePlayers.Front()->getLeftHand();
                    else
                        give = activePlayers.Front()->getRightHand();
                }

                //now add this "give" to the other player.
                if (other->one_empty())
                {
                    //add to the non-empty one
                    if (other->getLeftHand() != 0)
                        other->changeLeftHand(give);
                    else
                        other->changeRightHand(give);
                }
                else
                {
                    //ask for which hand would he like to add.
                    do
                    {
                        cout << "Which hand of the opponent would you like to give : (1. Left, 2. Right) ";
                        cin >> hand;
                    } while (hand != 1 && hand != 2);
                    hand == 1 ? other->changeLeftHand(give) : other->changeRightHand(give);
                }
            }
            else
            {
                //split
                int new_left, new_right;
                while (true)
                {
                    cout << "What will be the new left hand value : ";
                    cin >> new_left;
                    cout << "What will be the new right hand value : ";
                    cin >> new_right;

                    if (new_left + new_right != activePlayers.Front()->getRightHand() + activePlayers.Front()->getLeftHand())
                        cout << "The sum of left and right values should be equal to the previous sum." << endl;
                    else
                        break;
                }
                activePlayers.Front()->setLeftHand(new_left);
                activePlayers.Front()->setRightHand(new_right);
            }
        }
        else
        {
            //game is between two players No need to ask whom to give hand.
            do
            {
                cout << activePlayers.Front()->getName() << "'s turn, What do you want to do :\n1. Attack\n2. Split\nEnter your choice : ";
                cin >> choice;
            } while (choice != 1 && choice != 2);
            if (choice == 1)
            {
                if (activePlayers.Front()->one_empty())
                {
                    give = activePlayers.Front()->getLeftHand() != 0 ? activePlayers.Front()->getLeftHand() : activePlayers.Front()->getRightHand();
                }
                else
                {
                    do
                    {
                        cout << activePlayers.Front()->getName() << ", Which of your hand will you like to give : (1. Left, 2. Right) ";
                        cin >> hand;
                    } while (hand != 1 && hand != 2);
                    if (hand == 1)
                        give = activePlayers.Front()->getLeftHand();
                    else
                        give = activePlayers.Front()->getRightHand();
                }

                other = activePlayers.Rear();

                if (other->one_empty())
                {
                    other->getLeftHand() == 0 ? other->changeRightHand(give) : other->changeLeftHand(give);
                }
                else
                {
                    do
                    {
                        cout << activePlayers.Front()->getName() << ", Which hand of the opponent would you like to give : (1. Left, 2. Right) ";
                        cin >> hand;
                    } while (hand != 1 && hand != 2);
                    hand == 1 ? other->changeLeftHand(give) : other->changeRightHand(give);
                }
            }
            else
            {
                //split
                int new_left, new_right;
                while (true)
                {
                    cout << "What will be the new left hand value : ";
                    cin >> new_left;
                    cout << "What will be the new right hand value : ";
                    cin >> new_right;

                    if (new_left + new_right != activePlayers.Front()->getRightHand() + activePlayers.Front()->getLeftHand())
                        cout << "The sum of left and right values should be equal to the previous sum." << endl;
                    else
                        break;
                }
                activePlayers.Front()->setLeftHand(new_left);
                activePlayers.Front()->setRightHand(new_right);
            }
        }
        activePlayers.enqueue(activePlayers.Front());
        activePlayers.dequeue();
    }
    leaderBoard.push(players[activePlayers.Front()->getID()-1]);
    system("CLS");

    int counter = 1;
    int rank = 1;
    cout << "\n" << endl;
    cout << "\t\t\t---------Leader-Board---------" << endl;
    while(!leaderBoard.empty()){
        cout << "\t\t\t";
        cout << rank++ << ". " << leaderBoard.top().getName() << endl;
        leaderBoard.pop();
    }
}

void display(Player players[], int n)
{
    int counter = 1;
    cout << "\t\t\t\t\tLeft\tRight" << endl;
    for (int i = 0; i < n; i++)
    {
        cout << "\t\t";

        cout << players[i].getID() << ". " << players[i].getName() << " : ";
        gotoxy(42, counter++);
        cout << players[i].getLeftHand() << " \t  " << players[i].getRightHand();
        if (players[i].has_lost())
            cout << " (OUT)" << endl;
        else
            cout << endl;
    }
    cout << endl;
}

void gotoxy(int x, int y)
{
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
