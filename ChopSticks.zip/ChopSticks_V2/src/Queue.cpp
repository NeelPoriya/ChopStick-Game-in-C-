#include "Queue.h"

Queue::Queue()
{
    front = rear = NULL;
    SIZE = 0;
}

void Queue::enqueue(Player* p){
    ++SIZE;
    if(front == NULL && rear == NULL){
        front = new Node();
        front->player = p;
        front->link = NULL;
        rear = front;
    }
    else{
        rear->link = new Node();
        rear = rear->link;
        rear->player = p;
        rear->link = NULL;
    }
}

void Queue::display(){
    Node* frontCopy = front;
    while(frontCopy!=NULL){
        cout << frontCopy->player->getName() << ", ";
        frontCopy = frontCopy->link;
    }
    cout << endl;
}

Player* Queue::Front(){
    return front->player;
}

void Queue::dequeue(){
    --SIZE;
    if(front == NULL) return;
    Node* temp = front;
    front = front->link;
    if(front == NULL) rear = NULL;
    delete temp;
}

int Queue::size(){
    return SIZE;
}

bool Queue::empty(){
    return front == NULL && rear == NULL;
}

Player* Queue::Rear(){
    return rear->player;
}
