#include "Player.h"

Player::Player()
{
    left_hand = right_hand = 1;
}

string Player::getName(){
    return name;
}

void Player::setName(string _name){
    name = _name;
}

int Player::getLeftHand(){
    return left_hand;
}

void Player::setLeftHand(int value){
    left_hand = value%5;
}

int Player::getRightHand(){
    return right_hand;
}

void Player::setRightHand(int value){
    right_hand = value%5;
}

void Player::changeLeftHand(int value){
    left_hand = (left_hand+value)%5;
}

void Player::changeRightHand(int value){
    right_hand = (right_hand+value)%5;
}

bool Player::one_empty(){
    return left_hand == 0 || right_hand == 0;
}

int Player::getID(){
    return id;
}

void Player::setID(int value){
    id = value;
}

bool Player::has_lost(){
    return left_hand == 0 && right_hand == 0;
}
